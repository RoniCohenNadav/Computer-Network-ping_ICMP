#ifndef PING_H
#define PING_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/ip_icmp.h>
#include <netinet/ip6.h>
#include <netinet/ip.h>
#include <sys/time.h>
#include <errno.h>
#include <math.h>
#include <float.h>
#include <signal.h>
#include <limits.h>
#include <poll.h>
#include <netinet/icmp6.h>

#define PACKET_SIZE     64
#define PING_TIMEOUT    10 // Timeout in seconds

// Function prototypes
unsigned short checksum(void *b, int len);

struct icmp_packet {
    struct icmphdr icmp_hdr;
    char data[PACKET_SIZE - sizeof(struct icmphdr)];
};

struct icmp6_packet {
    struct icmp6_hdr icmp6_hdr;
    char data[PACKET_SIZE - sizeof(struct icmp6_hdr)];
};

void send_ping(int sockfd, struct sockaddr_in *dest_addr, struct sockaddr_in6 *dest_addr6, int ttl, int seq_num,
               double *total_time, int *received, double *min_time, double *max_time, int is_ipv6);

void handle_timeout(int sig);

#endif // PING_H